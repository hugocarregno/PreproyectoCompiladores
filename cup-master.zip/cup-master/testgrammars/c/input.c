int a=0;

int c;

void main(int d, int e){
    int f = 3;
    int h=f, b=0;
    h + 1; 

}
