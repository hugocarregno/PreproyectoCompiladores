# CUP - Creation of Useful Parsers

## Obtaining CUP

The bleeding edge binary release can be downloaded under https://versioncontrolseidl.in.tum.de/parsergenerators/cup/-/jobs/artifacts/master/download?job=build

